﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuyenSinhWinApp
{
    public static class Common
    {
        public static int MaNguoiDung { get; set; }
        public static string HoTen { get; set; }
        public static string MaTruong { get; set; }
        public static string TenTruong { get; set; }
        public static string MaDot { get; set; }
        public static string TenDangNhap { get; set; }
        public static string DiaChi { get; set; }
        public static string SoDienThoai { get; set; }
        public static string Email { get; set; }

        public static string VaiTro { get; set; }
        public static bool IsAdmin => VaiTro == "AdminSo";
        public static bool IsCanBo => string.Equals(VaiTro, "CanBoTruong", StringComparison.OrdinalIgnoreCase);
        public static bool IsThuKy =>
        string.Equals(VaiTro, "ThuKy", StringComparison.OrdinalIgnoreCase);


    }
}
