﻿namespace TuyenSinhWinApp
{
    partial class frmHocsinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHocsinh));
            this.txtHo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDanToc = new System.Windows.Forms.TextBox();
            this.txtNoiSinh = new System.Windows.Forms.TextBox();
            this.grpThongTin = new System.Windows.Forms.GroupBox();
            this.cboTruongTHCS = new System.Windows.Forms.ComboBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.cboTrangThai = new System.Windows.Forms.ComboBox();
            this.cboDotTuyen = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dgvDanhSachHocSinh = new System.Windows.Forms.DataGridView();
            this.hoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaTruong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maSoBaoDanhDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngaySinhDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gioiTinhDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.danTocDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noiSinhDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.truongTHCSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phongThiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diemToanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diemVanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diemAnhDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diemKhuyenKhichDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diemUuTienDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diemTongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hocSinhBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBoxXoa = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.excelpic = new System.Windows.Forms.PictureBox();
            this.PicThemMSBD = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtTimTen = new System.Windows.Forms.TextBox();
            this.cboLocTruongTHCS = new System.Windows.Forms.ComboBox();
            this.lblSoLuongHocSinh = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btnLoc = new System.Windows.Forms.Button();
            this.hocSinhBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnXuatTheDuThi = new System.Windows.Forms.Button();
            this.grpThongTin.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachHocSinh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hocSinhBindingSource1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxXoa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.excelpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicThemMSBD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hocSinhBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtHo
            // 
            this.txtHo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHo.Location = new System.Drawing.Point(47, 40);
            this.txtHo.Multiline = true;
            this.txtHo.Name = "txtHo";
            this.txtHo.Size = new System.Drawing.Size(241, 30);
            this.txtHo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "Họ :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDanToc
            // 
            this.txtDanToc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDanToc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDanToc.Location = new System.Drawing.Point(79, 156);
            this.txtDanToc.Multiline = true;
            this.txtDanToc.Name = "txtDanToc";
            this.txtDanToc.Size = new System.Drawing.Size(219, 28);
            this.txtDanToc.TabIndex = 2;
            // 
            // txtNoiSinh
            // 
            this.txtNoiSinh.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoiSinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoiSinh.Location = new System.Drawing.Point(89, 221);
            this.txtNoiSinh.Multiline = true;
            this.txtNoiSinh.Name = "txtNoiSinh";
            this.txtNoiSinh.Size = new System.Drawing.Size(209, 28);
            this.txtNoiSinh.TabIndex = 4;
            // 
            // grpThongTin
            // 
            this.grpThongTin.Controls.Add(this.cboTruongTHCS);
            this.grpThongTin.Controls.Add(this.txtTen);
            this.grpThongTin.Controls.Add(this.panel11);
            this.grpThongTin.Controls.Add(this.label12);
            this.grpThongTin.Controls.Add(this.label4);
            this.grpThongTin.Controls.Add(this.label5);
            this.grpThongTin.Controls.Add(this.label15);
            this.grpThongTin.Controls.Add(this.panel3);
            this.grpThongTin.Controls.Add(this.panel2);
            this.grpThongTin.Controls.Add(this.label3);
            this.grpThongTin.Controls.Add(this.label2);
            this.grpThongTin.Controls.Add(this.panel1);
            this.grpThongTin.Controls.Add(this.cboGioiTinh);
            this.grpThongTin.Controls.Add(this.dtpNgaySinh);
            this.grpThongTin.Controls.Add(this.txtHo);
            this.grpThongTin.Controls.Add(this.label1);
            this.grpThongTin.Controls.Add(this.txtDanToc);
            this.grpThongTin.Controls.Add(this.txtNoiSinh);
            this.grpThongTin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpThongTin.Location = new System.Drawing.Point(12, 22);
            this.grpThongTin.Name = "grpThongTin";
            this.grpThongTin.Size = new System.Drawing.Size(819, 277);
            this.grpThongTin.TabIndex = 8;
            this.grpThongTin.TabStop = false;
            this.grpThongTin.Text = "THÔNG TIN HỌC SINH";
            this.grpThongTin.Enter += new System.EventHandler(this.grpThongTin_Enter);
            // 
            // cboTruongTHCS
            // 
            this.cboTruongTHCS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTruongTHCS.FormattingEnabled = true;
            this.cboTruongTHCS.Items.AddRange(new object[] {
            "THCS Bình Phú",
            "THCS Hiếu Tử",
            "THCS Hiệp Mỹ Tây",
            "THCS Hiệp Thạnh",
            "THCS Hòa Thuận",
            "THCS Long Hòa",
            "THCS Long Vĩnh",
            "THCS Lý Tự Trọng",
            "THCS Minh Trí",
            "THCS Nguyễn Đáng",
            "THCS Ngũ Lạc",
            "THCS Phan Châu Trinh",
            "THCS Phương Thạnh",
            "THCS Phước Hưng",
            "THCS TT Châu Thành",
            "THCS TT Cầu Kè",
            "THCS TT Cầu Quan",
            "THCS TT Trà Cú",
            "THCS Thanh Mỹ",
            "THCS Thái Bình",
            "THCS Thị Trấn Cầu Kè",
            "THCS Trương Văn Trì",
            "THCS Trường Long Hòa",
            "THCS Trần Phú",
            "THCS Trần Quốc Tuấn",
            "THCS Tập Sơn",
            "THCS Đa Lộc",
            "THCS Đôn Châu",
            "THCS Đôn Xuân",
            "THCS Đại Phước",
            "THPT Hòa Lợi",
            "Thực hành Sư phạm"});
            this.cboTruongTHCS.Location = new System.Drawing.Point(486, 161);
            this.cboTruongTHCS.Name = "cboTruongTHCS";
            this.cboTruongTHCS.Size = new System.Drawing.Size(207, 26);
            this.cboTruongTHCS.TabIndex = 34;
            // 
            // txtTen
            // 
            this.txtTen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTen.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTen.Location = new System.Drawing.Point(57, 98);
            this.txtTen.Multiline = true;
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(241, 30);
            this.txtTen.TabIndex = 33;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(99)))), ((int)(((byte)(186)))));
            this.panel11.Location = new System.Drawing.Point(17, 140);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(281, 1);
            this.panel11.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 30);
            this.label12.TabIndex = 32;
            this.label12.Text = "Tên :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Location = new System.Drawing.Point(363, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 30);
            this.label4.TabIndex = 31;
            this.label4.Text = "Trường THCS :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(363, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 30);
            this.label5.TabIndex = 30;
            this.label5.Text = "Giới tính :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label15.Location = new System.Drawing.Point(363, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 30);
            this.label15.TabIndex = 29;
            this.label15.Text = "Ngày sinh :";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(99)))), ((int)(((byte)(186)))));
            this.panel3.Location = new System.Drawing.Point(17, 255);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(281, 1);
            this.panel3.TabIndex = 28;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(99)))), ((int)(((byte)(186)))));
            this.panel2.Location = new System.Drawing.Point(17, 193);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(281, 1);
            this.panel2.TabIndex = 27;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 30);
            this.label3.TabIndex = 28;
            this.label3.Text = "Nơi sinh :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 30);
            this.label2.TabIndex = 27;
            this.label2.Text = "Dân tộc :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(99)))), ((int)(((byte)(186)))));
            this.panel1.Location = new System.Drawing.Point(17, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(281, 1);
            this.panel1.TabIndex = 26;
            // 
            // cboGioiTinh
            // 
            this.cboGioiTinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboGioiTinh.FormattingEnabled = true;
            this.cboGioiTinh.Location = new System.Drawing.Point(486, 104);
            this.cboGioiTinh.Name = "cboGioiTinh";
            this.cboGioiTinh.Size = new System.Drawing.Size(95, 24);
            this.cboGioiTinh.TabIndex = 11;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgaySinh.Location = new System.Drawing.Point(486, 46);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(207, 22);
            this.dtpNgaySinh.TabIndex = 8;
            // 
            // cboTrangThai
            // 
            this.cboTrangThai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTrangThai.FormattingEnabled = true;
            this.cboTrangThai.Location = new System.Drawing.Point(9, 132);
            this.cboTrangThai.Name = "cboTrangThai";
            this.cboTrangThai.Size = new System.Drawing.Size(332, 24);
            this.cboTrangThai.TabIndex = 18;
            // 
            // cboDotTuyen
            // 
            this.cboDotTuyen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboDotTuyen.FormattingEnabled = true;
            this.cboDotTuyen.Location = new System.Drawing.Point(9, 54);
            this.cboDotTuyen.Name = "cboDotTuyen";
            this.cboDotTuyen.Size = new System.Drawing.Size(332, 24);
            this.cboDotTuyen.TabIndex = 25;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 30);
            this.label16.TabIndex = 33;
            this.label16.Text = "Khóa thi";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 30);
            this.label6.TabIndex = 34;
            this.label6.Text = "Trạng thái";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtGhiChu);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.cboDotTuyen);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cboTrangThai);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(857, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(359, 277);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGhiChu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhiChu.Location = new System.Drawing.Point(9, 207);
            this.txtGhiChu.Multiline = true;
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(332, 26);
            this.txtGhiChu.TabIndex = 34;
            this.txtGhiChu.TextChanged += new System.EventHandler(this.txtGhiChu_TextChanged);
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 174);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 30);
            this.label13.TabIndex = 35;
            this.label13.Text = "Ghi chú";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // dgvDanhSachHocSinh
            // 
            this.dgvDanhSachHocSinh.AutoGenerateColumns = false;
            this.dgvDanhSachHocSinh.BackgroundColor = System.Drawing.Color.White;
            this.dgvDanhSachHocSinh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachHocSinh.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.hoDataGridViewTextBoxColumn,
            this.tenDataGridViewTextBoxColumn,
            this.MaTruong,
            this.maSoBaoDanhDataGridViewTextBoxColumn,
            this.ngaySinhDataGridViewTextBoxColumn,
            this.gioiTinhDataGridViewTextBoxColumn,
            this.danTocDataGridViewTextBoxColumn,
            this.noiSinhDataGridViewTextBoxColumn,
            this.truongTHCSDataGridViewTextBoxColumn,
            this.phongThiDataGridViewTextBoxColumn,
            this.diemToanDataGridViewTextBoxColumn,
            this.diemVanDataGridViewTextBoxColumn,
            this.diemAnhDataGridViewTextBoxColumn,
            this.diemKhuyenKhichDataGridViewTextBoxColumn,
            this.diemUuTienDataGridViewTextBoxColumn,
            this.diemTongDataGridViewTextBoxColumn});
            this.dgvDanhSachHocSinh.DataSource = this.hocSinhBindingSource1;
            this.dgvDanhSachHocSinh.Location = new System.Drawing.Point(13, 384);
            this.dgvDanhSachHocSinh.Name = "dgvDanhSachHocSinh";
            this.dgvDanhSachHocSinh.Size = new System.Drawing.Size(1665, 607);
            this.dgvDanhSachHocSinh.TabIndex = 36;
            this.dgvDanhSachHocSinh.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhSachHocSinh_CellContentClick);
            // 
            // hoDataGridViewTextBoxColumn
            // 
            this.hoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.hoDataGridViewTextBoxColumn.DataPropertyName = "Ho";
            this.hoDataGridViewTextBoxColumn.HeaderText = "Họ";
            this.hoDataGridViewTextBoxColumn.Name = "hoDataGridViewTextBoxColumn";
            // 
            // tenDataGridViewTextBoxColumn
            // 
            this.tenDataGridViewTextBoxColumn.DataPropertyName = "Ten";
            this.tenDataGridViewTextBoxColumn.HeaderText = "Tên";
            this.tenDataGridViewTextBoxColumn.Name = "tenDataGridViewTextBoxColumn";
            // 
            // MaTruong
            // 
            this.MaTruong.DataPropertyName = "MaTruong";
            this.MaTruong.HeaderText = "Mã Trường";
            this.MaTruong.Name = "MaTruong";
            // 
            // maSoBaoDanhDataGridViewTextBoxColumn
            // 
            this.maSoBaoDanhDataGridViewTextBoxColumn.DataPropertyName = "MaSoBaoDanh";
            this.maSoBaoDanhDataGridViewTextBoxColumn.HeaderText = "Số báo danh";
            this.maSoBaoDanhDataGridViewTextBoxColumn.Name = "maSoBaoDanhDataGridViewTextBoxColumn";
            // 
            // ngaySinhDataGridViewTextBoxColumn
            // 
            this.ngaySinhDataGridViewTextBoxColumn.DataPropertyName = "NgaySinh";
            this.ngaySinhDataGridViewTextBoxColumn.HeaderText = "Ngày sinh";
            this.ngaySinhDataGridViewTextBoxColumn.Name = "ngaySinhDataGridViewTextBoxColumn";
            // 
            // gioiTinhDataGridViewTextBoxColumn
            // 
            this.gioiTinhDataGridViewTextBoxColumn.DataPropertyName = "GioiTinh";
            this.gioiTinhDataGridViewTextBoxColumn.HeaderText = "Giới tính";
            this.gioiTinhDataGridViewTextBoxColumn.Name = "gioiTinhDataGridViewTextBoxColumn";
            // 
            // danTocDataGridViewTextBoxColumn
            // 
            this.danTocDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.danTocDataGridViewTextBoxColumn.DataPropertyName = "DanToc";
            this.danTocDataGridViewTextBoxColumn.HeaderText = "Dân tộc";
            this.danTocDataGridViewTextBoxColumn.Name = "danTocDataGridViewTextBoxColumn";
            // 
            // noiSinhDataGridViewTextBoxColumn
            // 
            this.noiSinhDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.noiSinhDataGridViewTextBoxColumn.DataPropertyName = "NoiSinh";
            this.noiSinhDataGridViewTextBoxColumn.HeaderText = "Nơi sinh";
            this.noiSinhDataGridViewTextBoxColumn.Name = "noiSinhDataGridViewTextBoxColumn";
            // 
            // truongTHCSDataGridViewTextBoxColumn
            // 
            this.truongTHCSDataGridViewTextBoxColumn.DataPropertyName = "TruongTHCS";
            this.truongTHCSDataGridViewTextBoxColumn.HeaderText = "Học sinh trường ";
            this.truongTHCSDataGridViewTextBoxColumn.Name = "truongTHCSDataGridViewTextBoxColumn";
            this.truongTHCSDataGridViewTextBoxColumn.Width = 200;
            // 
            // phongThiDataGridViewTextBoxColumn
            // 
            this.phongThiDataGridViewTextBoxColumn.DataPropertyName = "PhongThi";
            this.phongThiDataGridViewTextBoxColumn.HeaderText = "Phòng thi";
            this.phongThiDataGridViewTextBoxColumn.Name = "phongThiDataGridViewTextBoxColumn";
            // 
            // diemToanDataGridViewTextBoxColumn
            // 
            this.diemToanDataGridViewTextBoxColumn.DataPropertyName = "DiemToan";
            this.diemToanDataGridViewTextBoxColumn.HeaderText = "Toán";
            this.diemToanDataGridViewTextBoxColumn.Name = "diemToanDataGridViewTextBoxColumn";
            this.diemToanDataGridViewTextBoxColumn.Width = 50;
            // 
            // diemVanDataGridViewTextBoxColumn
            // 
            this.diemVanDataGridViewTextBoxColumn.DataPropertyName = "DiemVan";
            this.diemVanDataGridViewTextBoxColumn.HeaderText = "Văn";
            this.diemVanDataGridViewTextBoxColumn.Name = "diemVanDataGridViewTextBoxColumn";
            this.diemVanDataGridViewTextBoxColumn.Width = 50;
            // 
            // diemAnhDataGridViewTextBoxColumn
            // 
            this.diemAnhDataGridViewTextBoxColumn.DataPropertyName = "DiemAnh";
            this.diemAnhDataGridViewTextBoxColumn.HeaderText = "Điểm môn tự chọn";
            this.diemAnhDataGridViewTextBoxColumn.Name = "diemAnhDataGridViewTextBoxColumn";
            this.diemAnhDataGridViewTextBoxColumn.Width = 50;
            // 
            // diemKhuyenKhichDataGridViewTextBoxColumn
            // 
            this.diemKhuyenKhichDataGridViewTextBoxColumn.DataPropertyName = "DiemKhuyenKhich";
            this.diemKhuyenKhichDataGridViewTextBoxColumn.HeaderText = "Điểm KK";
            this.diemKhuyenKhichDataGridViewTextBoxColumn.Name = "diemKhuyenKhichDataGridViewTextBoxColumn";
            this.diemKhuyenKhichDataGridViewTextBoxColumn.Width = 50;
            // 
            // diemUuTienDataGridViewTextBoxColumn
            // 
            this.diemUuTienDataGridViewTextBoxColumn.DataPropertyName = "DiemUuTien";
            this.diemUuTienDataGridViewTextBoxColumn.HeaderText = "Điểm ƯT";
            this.diemUuTienDataGridViewTextBoxColumn.Name = "diemUuTienDataGridViewTextBoxColumn";
            this.diemUuTienDataGridViewTextBoxColumn.Width = 50;
            // 
            // diemTongDataGridViewTextBoxColumn
            // 
            this.diemTongDataGridViewTextBoxColumn.DataPropertyName = "DiemTong";
            this.diemTongDataGridViewTextBoxColumn.HeaderText = "Tổng điểm";
            this.diemTongDataGridViewTextBoxColumn.Name = "diemTongDataGridViewTextBoxColumn";
            this.diemTongDataGridViewTextBoxColumn.Width = 50;
            // 
            // hocSinhBindingSource1
            // 
            this.hocSinhBindingSource1.DataSource = typeof(TuyenSinhServiceLib.HocSinh);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.pictureBoxXoa);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.excelpic);
            this.groupBox2.Controls.Add(this.PicThemMSBD);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(1237, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(441, 277);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(68, 39);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(36, 36);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 49;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(322, 73);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 30);
            this.label17.TabIndex = 48;
            this.label17.Text = "Xóa";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxXoa
            // 
            this.pictureBoxXoa.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxXoa.Image")));
            this.pictureBoxXoa.Location = new System.Drawing.Point(338, 40);
            this.pictureBoxXoa.Name = "pictureBoxXoa";
            this.pictureBoxXoa.Size = new System.Drawing.Size(36, 36);
            this.pictureBoxXoa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxXoa.TabIndex = 47;
            this.pictureBoxXoa.TabStop = false;
            this.pictureBoxXoa.Click += new System.EventHandler(this.pictureBoxXoa_Click);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(182, 73);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 30);
            this.label14.TabIndex = 46;
            this.label14.Text = "Sửa";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(199, 39);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(36, 36);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(313, 203);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 30);
            this.label10.TabIndex = 43;
            this.label10.Text = "Load danh sách";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(182, 201);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 30);
            this.label8.TabIndex = 42;
            this.label8.Text = "File Excel";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(50, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 30);
            this.label7.TabIndex = 41;
            this.label7.Text = "Tạo SBD";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(50, 73);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 30);
            this.label9.TabIndex = 33;
            this.label9.Text = "Thêm";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // excelpic
            // 
            this.excelpic.Image = ((System.Drawing.Image)(resources.GetObject("excelpic.Image")));
            this.excelpic.Location = new System.Drawing.Point(199, 161);
            this.excelpic.Name = "excelpic";
            this.excelpic.Size = new System.Drawing.Size(36, 36);
            this.excelpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.excelpic.TabIndex = 37;
            this.excelpic.TabStop = false;
            this.excelpic.Click += new System.EventHandler(this.excelpic_Click);
            // 
            // PicThemMSBD
            // 
            this.PicThemMSBD.Image = ((System.Drawing.Image)(resources.GetObject("PicThemMSBD.Image")));
            this.PicThemMSBD.Location = new System.Drawing.Point(68, 161);
            this.PicThemMSBD.Name = "PicThemMSBD";
            this.PicThemMSBD.Size = new System.Drawing.Size(36, 36);
            this.PicThemMSBD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PicThemMSBD.TabIndex = 40;
            this.PicThemMSBD.TabStop = false;
            this.PicThemMSBD.Click += new System.EventHandler(this.PicThemMSBD_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(338, 161);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 36);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(12, 339);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(250, 30);
            this.label18.TabIndex = 36;
            this.label18.Text = "DANH SÁCH HỌC SINH";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTimTen
            // 
            this.txtTimTen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimTen.Location = new System.Drawing.Point(1063, 336);
            this.txtTimTen.Multiline = true;
            this.txtTimTen.Name = "txtTimTen";
            this.txtTimTen.Size = new System.Drawing.Size(232, 34);
            this.txtTimTen.TabIndex = 37;
            // 
            // cboLocTruongTHCS
            // 
            this.cboLocTruongTHCS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboLocTruongTHCS.FormattingEnabled = true;
            this.cboLocTruongTHCS.Location = new System.Drawing.Point(786, 344);
            this.cboLocTruongTHCS.Name = "cboLocTruongTHCS";
            this.cboLocTruongTHCS.Size = new System.Drawing.Size(172, 24);
            this.cboLocTruongTHCS.TabIndex = 38;
            // 
            // lblSoLuongHocSinh
            // 
            this.lblSoLuongHocSinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoLuongHocSinh.Location = new System.Drawing.Point(10, 1006);
            this.lblSoLuongHocSinh.Name = "lblSoLuongHocSinh";
            this.lblSoLuongHocSinh.Size = new System.Drawing.Size(391, 26);
            this.lblSoLuongHocSinh.TabIndex = 44;
            this.lblSoLuongHocSinh.Text = "Tổng số học sinh có trong danh sách: 0 học sinh\r\n";
            this.lblSoLuongHocSinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(665, 341);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 30);
            this.label20.TabIndex = 46;
            this.label20.Text = "Trường THCS :";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(975, 338);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(82, 30);
            this.label21.TabIndex = 47;
            this.label21.Text = "Tên :";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLoc
            // 
            this.btnLoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoc.Image = global::TuyenSinhWinApp.Properties.Resources.filter;
            this.btnLoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoc.Location = new System.Drawing.Point(1317, 333);
            this.btnLoc.Name = "btnLoc";
            this.btnLoc.Size = new System.Drawing.Size(132, 36);
            this.btnLoc.TabIndex = 43;
            this.btnLoc.Text = "Lọc";
            this.btnLoc.UseVisualStyleBackColor = true;
            this.btnLoc.Click += new System.EventHandler(this.btnLoc_Click);
            // 
            // hocSinhBindingSource
            // 
            this.hocSinhBindingSource.DataSource = typeof(TuyenSinhServiceLib.HocSinh);
            // 
            // btnXuatTheDuThi
            // 
            this.btnXuatTheDuThi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXuatTheDuThi.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatTheDuThi.Image = global::TuyenSinhWinApp.Properties.Resources.excel;
            this.btnXuatTheDuThi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatTheDuThi.Location = new System.Drawing.Point(1465, 333);
            this.btnXuatTheDuThi.Name = "btnXuatTheDuThi";
            this.btnXuatTheDuThi.Size = new System.Drawing.Size(213, 36);
            this.btnXuatTheDuThi.TabIndex = 69;
            this.btnXuatTheDuThi.Text = "Xuất thẻ dự thi toàn bộ học sinh";
            this.btnXuatTheDuThi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatTheDuThi.UseVisualStyleBackColor = true;
            this.btnXuatTheDuThi.Click += new System.EventHandler(this.btnXuatTheDuThi_Click);
            // 
            // frmHocsinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1690, 1041);
            this.Controls.Add(this.btnXuatTheDuThi);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.lblSoLuongHocSinh);
            this.Controls.Add(this.btnLoc);
            this.Controls.Add(this.cboLocTruongTHCS);
            this.Controls.Add(this.txtTimTen);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgvDanhSachHocSinh);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpThongTin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmHocsinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Học Sinh";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmHocsinh_Load);
            this.grpThongTin.ResumeLayout(false);
            this.grpThongTin.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachHocSinh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hocSinhBindingSource1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxXoa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.excelpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicThemMSBD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hocSinhBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtHo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDanToc;
        private System.Windows.Forms.TextBox txtNoiSinh;
        private System.Windows.Forms.GroupBox grpThongTin;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.ComboBox cboTrangThai;
        private System.Windows.Forms.ComboBox cboDotTuyen;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.BindingSource hocSinhBindingSource;
        private System.Windows.Forms.DataGridView dgvDanhSachHocSinh;
        private System.Windows.Forms.BindingSource hocSinhBindingSource1;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox excelpic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox PicThemMSBD;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBoxXoa;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cboTruongTHCS;
        private System.Windows.Forms.TextBox txtTimTen;
        private System.Windows.Forms.ComboBox cboLocTruongTHCS;
        private System.Windows.Forms.Button btnLoc;
        private System.Windows.Forms.Label lblSoLuongHocSinh;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridViewTextBoxColumn hoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTruong;
        private System.Windows.Forms.DataGridViewTextBoxColumn maSoBaoDanhDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngaySinhDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gioiTinhDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn danTocDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noiSinhDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn truongTHCSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phongThiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diemToanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diemVanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diemAnhDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diemKhuyenKhichDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diemUuTienDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diemTongDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnXuatTheDuThi;
    }
}